package com.amdocs;
import java.util.*;
public class DecisisionControlDemo {
	public static void main(String[] args) {
		int time;
		System.out.println("enter the time: ");
		Scanner sc = new Scanner(System.in);
		time=sc.nextInt();
		if(time==9) {
			System.out.println("welcome");
		}else {
			System.out.println("error");
		}
		if(time>=9 && time<11 || time>11&&time<13||time>=14&&time<16||time>16&&time<18) {
			System.out.println("Welcome to Java amdocs session");
		}else if(time==11||time==16) {
			System.out.println("15 minutes tea break");
		}else if(time==13) {
			System.out.println("lunch break");
		}else if(time>=18 &&time<24) {
			System.out.println("session is ended we will start it the next day");
		}else if(time>0 &&time<9) {
			System.out.println("yet to start the session");
		}else {
			System.out.println("invalid time");
		}
	}
}
