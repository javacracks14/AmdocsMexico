package com.amdocs;

public class IterativeDemo {
	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			System.out.println("Hello");
		}
		System.out.println("outside loop");
		int x=0;
		while(x<=7) {
			x++;
		}
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				System.out.println(i+" ");
			}
		}
		for(int i=1;i<=10;i++) {
			if(i==5) {
				continue;
			}
			else {
				System.out.println(i+"hello java developers");
			}
		}
	}
}
