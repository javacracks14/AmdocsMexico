package com.amdocs;

public class DataTypesDemo {
	public static void main(String[] args) {
		int wholeNumber;
		wholeNumber=10;
		float decimalNumber1=12.36f;
		char singleAlphabet='a';
		boolean value = true;
		long longIntValue =1212121;
		short shortIntValue=122;
		System.out.println("the value of the number is: "+wholeNumber);
	}
}
