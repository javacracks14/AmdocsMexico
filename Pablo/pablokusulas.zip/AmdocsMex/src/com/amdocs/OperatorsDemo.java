package com.amdocs;

public class OperatorsDemo {
	public static void main(String[] args) {
		int number1=10,number2=8,output,number3 =8;
		output = number1+=number2;
		System.out.println("Addition"+output);
		output = number1-=number2;
		System.out.println("Substraction"+output);
		output = number1*=number2;
		System.out.println("multiplication"+output);
		output = number1/=number2;
		System.out.println("Division"+output);
		output = number1%=number2;
		System.out.println("module"+output);
		System.out.println("Logical and operator value is: "+(number1>number2 && number1==number3));
		System.out.println("Logical or operator value is: "+(number1>number2 || number1==number3));
		System.out.println("Logical not operator value is: "+(number1>number2 && number1!=number3));
		System.out.println(number1>number2?"Number1 is greater":"Number2 is greater");
	}
}
