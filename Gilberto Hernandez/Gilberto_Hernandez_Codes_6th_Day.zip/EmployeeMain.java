package com.amdocs.basic;

public class EmployeeMain {
	public static void main(String[] args) {
		Manager manObj = new Manager(1000,30000);
		manObj.dispEmployeeRecords();
		manObj.dispManagerRecords();
		manObj.calculateSalary();
		
		System.out.println();
		
		Employee empObj = new Employee();
		empObj.dispEmployeeRecords();
		empObj.calculateSalary();
		
		System.out.println();
		
		Employee empObj1 = new Manager(25,15000.0);
		empObj1.dispEmployeeRecords();
		empObj1.calculateSalary();
		((Manager)empObj1).dispManagerRecords();
	}
}
