package com.amdocs.basic;

public abstract class Shape {
	public void shapeType () {			// Non-Abstract method 
		System.out.println("This is the structure of a shape.");
	}
	
	public abstract void area();		// Abstract method
}
