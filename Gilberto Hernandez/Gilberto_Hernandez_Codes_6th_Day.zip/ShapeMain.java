package com.amdocs.basic;

public class ShapeMain {
	public static void main(String[] args) {
		Rectangle rObj = new Rectangle();
		rObj.shapeType();
		rObj.area();
	}
}
