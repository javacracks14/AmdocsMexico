package com.amdocs.basic;

public class Employee {
	private int empid;
	private String name;
	private double salary;
	
	public Employee() {
		empid = 101;
		name = "John";
		salary = 25000.0;
		System.out.println("Employee Default Constructor.");
	}
	
	public Employee(int empid, String name, double salary) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		System.out.println("Employee Parameterized Constructor.");
	}
	
	public void dispEmployeeRecords() {
		System.out.println("EMPID: " + empid + "\nNAME: " + name + "\nSALARY: " + salary);
	}
	
	public void calculateSalary() {
		System.out.println("DEDUCTION: 200\nNET SALARY: " + (this.salary - 200));
	}

	public double getSalary() {
		return salary;
	}
}
