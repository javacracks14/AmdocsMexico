package com.amdocs.basic;

public class Calculator {
	public void add(int a, int b) {
		System.out.println("Adding (int, int): " + (a+b));
	}
	
	public void add(int a, float b) {
		System.out.println("Adding (int, float): " + (a+b));
	}
	
	public void add(float a, int b) {
		System.out.println("Adding (float, int): " + (a+b));
	}
	
	public void add(float a, float b) {
		System.out.println("Adding (float, float): " + (a+b));
	}
}
