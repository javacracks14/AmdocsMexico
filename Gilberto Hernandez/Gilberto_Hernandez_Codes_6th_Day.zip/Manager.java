package com.amdocs.basic;

public class Manager extends Employee {
	private int totalReportees;
	private double bonus;
	
	public Manager() {
		totalReportees = 10;
		bonus = 10000.0;
		System.out.println("Manager Default Constructor.");
	}
	
	public Manager(int totalReportees, double bonus) {
		super(102, "Luis", 100000.0);
		this.totalReportees = totalReportees;
		this.bonus = bonus;
		System.out.println("Manager Parameterized Constructor.");
	}
	
	public void dispManagerRecords() {
		System.out.println("TOTAL REPORTEES: " + totalReportees + "\nBONUS: " + bonus);
	}
	
	@Override
	public void calculateSalary() {
		System.out.println("DEDUCTION: 500\nNET SALARY: " + (super.getSalary() + bonus - 500));
	}
}
