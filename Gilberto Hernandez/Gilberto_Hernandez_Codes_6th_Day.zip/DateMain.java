package com.amdocs.basic;

public class DateMain {
	public static void main(String[] args) {
		MyDate dateObj = new MyDate();
		dateObj.displayDate();
		
		System.out.println();
		
		MyDate dateObj1 = new MyDate(12,25,2025);
		dateObj1.displayDate();
		dateObj1.setDay(31);
		System.out.println("Day was updated to " + dateObj1.getDay());
		dateObj1.displayDate();
	}
}
