package com.amdocs.basic;

public class Rectangle extends Shape {
	@Override
	public void area() {
		System.out.println("Area of a rectangle is (lenght * base * height).");
	}
}
