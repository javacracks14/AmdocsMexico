package com.amdocs.basic;

public class MyDate {
	private int day, month, year;		// Class variables
	
	public MyDate() {		// Default constructor
		month = 8;
		day = 20;
		year = 2025;
		System.out.println("Calling default constructors.");
	}
	
	public MyDate(int month, int day, int year) {
		//this();		// Calling of my default constructor  ---> Should always be first line in other constructors
		this.month = month;
		this.day = day;
		this.year = year;
		System.out.println("Calling parameterized constructors.");
	}
	
	public void displayDate() {
		System.out.println("Today's Date is " + this.getMonth() + "/" + this.getDay() + "/" + this.getYear() + ".");
	}
	
	public int getDay() {
		return day;
	}
	
	public void setDay(int d) {
		day = d;
	}
	
	public int getMonth() {
		return month;
	}
	
	public void setMonth(int m) {
		month = m;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int y) {
		year = y;
	}
	
	
}
