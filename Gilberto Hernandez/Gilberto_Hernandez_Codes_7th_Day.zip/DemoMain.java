package com.amdocs.seventhDay;

public class DemoMain {
	public static void main(String[] args) {
		JavaEightInterface Obj = new JavaEightInterface();
		Obj.showMessage();
		
		Demo.sayHi();
	}
}
