package com.amdocs.seventhDay;

public class Employee {
	private int empid;
	private String name;
	private double salary;
	private static int count;
	
	public Employee() {
		empid = 101;
		name = "John";
		salary = 25000.0;
		System.out.println("Employee Default Constructor.");
	}
	
	public Employee(int empid, String name, double salary) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		count ++;
	}
	
	public void dispEmployeeRecords() {
		System.out.println("EMPID: " + empid + "\nNAME: " + name + "\nSALARY: " + salary + "\n");
	}
	
	public static void dispTotalEmployeeRecords() {
		System.out.println("COUNT = " + count);
	}
}
