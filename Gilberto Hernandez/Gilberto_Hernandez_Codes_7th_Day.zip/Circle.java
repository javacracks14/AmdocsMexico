package com.amdocs.seventhDay;

public class Circle implements Shape {
	@Override
	public void area() {
		System.out.println("Area of a Circle.");
	}
	
	@Override
	public void volume() {
		System.out.println("Volume of a Circle.");
	}
}
