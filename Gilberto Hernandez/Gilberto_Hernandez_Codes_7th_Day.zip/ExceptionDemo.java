package com.amdocs.seventhDay;

public class ExceptionDemo {
	public static void main(String[] args) {
		int number1 = 10 , number2 = 0 , output;
		
		System.out.println("***************\nWith Exception Handling\n***************");
		exceptionHandling(number1, number2);
		
		System.out.println();

		System.out.println("***************\nWith Throw Exception Handling\n***************");
		throwException(number1, number2);
	
		System.out.println();

		System.out.println("***************\nWith Throws Exception Handling\n***************");
		throwsException(number1, number2);
		
		System.out.println();
		
		System.out.println("***************\nWithout Exception Handling\n***************");
		System.out.println("Start");
		output = number1 / number2;
		System.out.println("Division Value is: " + output);
		System.out.println("Stop");
	}
	
	public static void exceptionHandling(int num1, int num2) {
		System.out.println("Start");
		try {
			int output = num1 / num2;
			System.out.println("Division Value is: " + output);
		}
		catch(ArithmeticException ex) {
			System.out.println(ex);
		}
		finally {
			System.out.println("Finally block");
		}
		System.out.println("Stop");
	}
	
	public static void throwException(int num1, int num2) {
		System.out.println("Start");
		try {
			Calculator calc = new Calculator();
			calc.divide(num1, num2);
		}
		catch(ArithmeticException ex) {
			System.out.println(ex);
		}
		finally {
			System.out.println("Finally block");
		}
		System.out.println("Stop");
	}
	
	public static void throwsException(int num1, int num2) {
		System.out.println("Start");
		try {
			Calculator calc = new Calculator();
			calc.divideThrows(num1, num2);
		}
		catch(ArithmeticException ex) {
			System.out.println(ex);
		}
		finally {
			System.out.println("Finally block");
		}
		System.out.println("Stop");
	}
}