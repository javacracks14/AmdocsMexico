package com.amdocs.seventhDay;

public interface Demo {
	default void showMessage() {
		System.out.println("We are learning Java 8 Interfaces.");
	}

	static void sayHi() {
		System.out.println("Welcome to the new Java 8.");
	}
}
