package com.amdocs.seventhDay;

public class GenericMain {
	public static void main(String[] args) {
		Generic<Integer> gen1 = new Generic<Integer>(10);
		System.out.println(gen1.getNum());
		
		Generic<Float> gen2 = new Generic<Float>(14.56f);
		System.out.println(gen2.getNum());
	}
}
