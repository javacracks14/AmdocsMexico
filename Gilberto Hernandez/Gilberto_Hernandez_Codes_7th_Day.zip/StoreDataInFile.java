package com.amdocs.seventhDay;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.io.DataOutputStream;

public class StoreDataInFile {
	public static void main(String[] args) throws IOException {
		File file = new File("demo.txt");
		if(file.exists()) {
			System.out.println("File is Available in specified path.");
		}
		else {
			file.createNewFile();
			System.out.println("File is created.");
		}
		
		fileWithContent();
		fileOutputStream();
		dataOutputStream();
	}
	
	public static void fileWithContent() throws IOException {
		String data = "We are learning File Handling in Java.";
		FileWriter fw = new FileWriter("character.txt"); 	//Opening a File
		fw.write(data);
		fw.close();
		System.out.println("Data is stored in character.txt file.");
	}
	
	public static void fileOutputStream() throws IOException {
		String data = "We are learning File Handling in Java. This is written with bytes.";
		FileOutputStream fw = new FileOutputStream("bytes.txt"); 	//Opening a File
		byte[] bData = data.getBytes();
		fw.write(bData);
		fw.close();
		System.out.println("Data is stored in bytes.txt file.");
	}
	
	public static void dataOutputStream() throws IOException {
		int highScore = 10000001;
		FileOutputStream fw = new FileOutputStream("data.txt"); 	//Opening a File
		DataOutputStream ds = new DataOutputStream(fw);
		ds.writeInt(highScore);
		ds.close();
		fw.close();
		System.out.println("Data is stored in data.txt file.");
	}
}
