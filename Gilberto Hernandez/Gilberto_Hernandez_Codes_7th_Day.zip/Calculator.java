package com.amdocs.seventhDay;

public class Calculator {
	public void divide(int num1, int num2) {
		if(num2 == 0) {
			throw new ArithmeticException("It's not possible to divide by zero.");
		}
		else {
			System.out.println(num1/num2);
		}
	}
	
	public void divideThrows(int num1, int num2) throws ArithmeticException {
		System.out.println(num1/num2);
	}
}
