package com.amdocs.seventhDay;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.DataInputStream;

public class ReadingFromFile {
	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("character.txt");
		int ch;
		while((ch=fr.read()) != -1) {
			System.out.print((char) ch);
		}
		
		System.out.println("\ncharacter.txt file is read successfully.");
		fr.close();
		
		System.out.println();
		fileInputStream();
		
		System.out.println();
		dataInputStream();
	}
	
	public static void fileInputStream() throws IOException {
		FileInputStream fr = new FileInputStream("bytes.txt");
		int ch;
		while((ch=fr.read()) != -1) {
			System.out.print((char) ch);
		}
		
		System.out.println("\nbytes.txt file is read successfully.");
		fr.close();
	}
	
	public static void dataInputStream() throws IOException {
		FileInputStream fw = new FileInputStream("data.txt");
		DataInputStream ds = new DataInputStream(fw);
		
		int highScore = ds.readInt();
		System.out.println(highScore);
		
		System.out.println("data.txt is read successfully.");
		ds.close();
		fw.close();
	}
}
