package com.amdocs.seventhDay;

public interface Shape {
	void area();
	void volume();
}
