package com.amdocs.seventhDay;

public class JavaEightInterface implements Demo {
	@Override
	public void showMessage() {
		System.out.println("We are overriding the showMessage Demo Method in a class.");
	}
	
}
