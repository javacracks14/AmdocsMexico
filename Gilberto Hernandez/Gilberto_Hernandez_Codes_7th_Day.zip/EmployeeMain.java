package com.amdocs.seventhDay;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(101, "Jason", 50000.0);
		Employee.dispTotalEmployeeRecords();
		Employee employee2 = new Employee(102, "Tracy", 32000.0);
		Employee.dispTotalEmployeeRecords();
		Employee employee3 = new Employee(103, "Victor", 32000.0);
		Employee.dispTotalEmployeeRecords();
	}
}
