package com.amdocs.seventhDay;

public class Generic<T extends Number> {
	private T num;
	
	public Generic(T num) {
		this.num = num;
	}
	
	public T getNum() {
		return num;
	}
}
