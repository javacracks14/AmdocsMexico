package com.amdocs.seventhDay;

public class ShapeMain {
	public static void main(String[] args) {
		Circle cObj = new Circle();
		cObj.area();
		cObj.volume();
	}
}
