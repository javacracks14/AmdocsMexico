package com.amdocs;

public class IterativeDemo {
	public static void main(String[] args) {
		forloop();
		System.out.println();
		
		whileloop();
		System.out.println();
		
		dowhileloop();
		System.out.println();
		
		nestedloop();
		System.out.println();
	}
	
	public static void forloop() {
		for(int i=1 ; i<=10; i++) {
			System.out.println("Hello Java Developers.");
		}
		System.out.println("Outside the loop.");
	}
	
	public static void whileloop() {
		int i = 1;
		while(i<=7) {
			System.out.println("Hello Java Developers.");
			i++;
		}
		System.out.println("Outside the loop.");
	}
	
	public static void dowhileloop() {
		int i = 1;
		do {
			System.out.println("Hello Java Developers.");
			i++;
		} while(i<=7);
		
		System.out.println("Outside the loop.");
	}
	
	public static void nestedloop() {
		for(int row=1; row<=5; row++) {
			for(int col=1; col<=5; col++) {
				System.out.print(row + " ");
			}
			System.out.println();
		}
		System.out.println("Outside the loop.");
	}
}
