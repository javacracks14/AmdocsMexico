package com.amdocs;
import java.util.Scanner;

public class DecisionControlDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		ifFunction(sc);
		System.out.println();
		
		ifElse(sc);
		System.out.println();
		
		nestedIf(sc);
		System.out.println();
		
		elseIf(sc);
	}
	
	public static void ifFunction(Scanner sc) {
		int time;
		System.out.println("Enter the Time: ");
		time = sc.nextInt();
		
		if(time==9) {
			System.out.println("Welcome to Amdocs Java Session.");
		}
	}
	
	public static void ifElse(Scanner sc) {
		int time;
		System.out.println("Enter the Time: ");
		time = sc.nextInt();
		
		if(time==9) {
			System.out.println("Welcome to Amdocs Java Session.");
		}
		else {
			System.out.println("Error...");
		}
	}
	
	public static void nestedIf(Scanner sc) {
		int number;
		System.out.println("Enter the Number: ");
		number = sc.nextInt();
		
		if(number>=0) {
			if(number==0) {
				System.out.println("Number is neither positive nor negative.");
			}
			else {
				System.out.println("Positive Number.");
			}
		}
		else {
			System.out.println("Negative Number.");
		}
	}
	
	public static void elseIf(Scanner sc) {
		int time;
		System.out.println("Enter the Time: ");
		time = sc.nextInt();
		if(time>=9 && time<11 || time>11 && time<13 || time>=14 && time<16 || time>16 && time<18) {
			System.out.println("Welcome to Amdocs Java Session.");
		}
		else if(time==11 || time==16) {
			System.out.println("15 minutes Tea Break.");
		}
		else if(time==13) {
			System.out.println("Lunch Break.");
		}
		else if(time>=18 && time<24) {
			System.out.println("Session is Ended. We will start it next day.");	
		}
		else if(time>0 && time<9) {
			System.out.println("Yet to Start the Session. Please wait till 9:00AM.");
		}
		else {
			System.out.println("Invalid Time...");
		}
	}
}
