package com.amdocs;

public class OperatorsDemo {
	public static void main(String[] args) {
		int number1 = 10, number2 = 8, number3 = 8, output = 0;
		
		operators(number1, number2, output);
		System.out.println("\n");

		compressed(number1, number2);
		System.out.println("\n");

		comparison(number1, number2);
		System.out.println("\n");

		logicalOperator(number1, number2, number3);
		System.out.println("\n");

		increments(number1);
		System.out.println("\n");

		conditionInLine(number1, number2);
		System.out.println("\n");
	}
	
	public static void operators(int num1, int num2, int output) {
		output = num1 + num2;
		System.out.println("Addition output is: " + output);
		
		output = num1 + num2;
		System.out.println("Substraction output is: " + output);
		
		output = num1 * num2;
		System.out.println("Multiplication output is: " + output);
		
		output = num1 / num2;
		System.out.println("Division output is: " + output);
		
		output = num1 % num2;
		System.out.println("Modulus output is: " + output);
	}
	
	public static void compressed(int num1, int num2) {
		System.out.println("Number1 value is: " + num1 + "\tNumber2 value is: " + num2);
		num1 += num2;
		num1 -= num2;
		num1 *= num2;
		num1 /= num2;
		System.out.println("Number1 value is: " + num1 + "\tNumber2 value is: " + num2);
	}
	
	public static void comparison(int num1, int num2) {
		System.out.println("Comparison for Greater Than: " + (num1 > num2));
		System.out.println("Comparison for Greater Than or Equal To: " + (num1 >= num2));
		System.out.println("Comparison for Less Than: " + (num1 < num2));
		System.out.println("Comparison for Less Than or Equal To: " + (num1 <= num2));
		System.out.println("Comparison for Equal To: " + (num1 == num2));
		System.out.println("Comparison for Not Equal To: " + (num1 != num2));
	}
	
	public static void logicalOperator(int num1, int num2, int num3) {
		System.out.println("Logical AND operator value is: " + (num1 > num2 && num1 == num3));
		System.out.println("Logical OR operator value is: " + (num1 > num2 || num1 == num3));
		System.out.println("Logical NOT operator value is: " + (num1 > num2 && num1 != num3));
	}
	
	public static void increments(int num1) {
		System.out.println("Value of Number is: " + num1);
		System.out.println("Increment operatrion: " + (num1++));
		System.out.println("Value of Number After Increment: " + num1);
		System.out.println();
		System.out.println("Value of Number is: " + num1);
		System.out.println("Increment operatrion: " + (++num1));
		System.out.println("Value of Number After Increment: " + num1);
		System.out.println();
		System.out.println("Value of Number is: " + num1);
		System.out.println("Increment operatrion: " + (num1--));
		System.out.println("Value of Number After Decrement: " + num1);
		System.out.println();
		System.out.println("Value of Number is: " + num1);
		System.out.println("Increment operatrion: " + (--num1));
		System.out.println("Value of Number After Decrement: " + num1);
	}
	
	public static void conditionInLine(int num1, int num2) {
		System.out.println(num1>num2?"Number1 is Greater":"Number2 is Greater");
	}
}
