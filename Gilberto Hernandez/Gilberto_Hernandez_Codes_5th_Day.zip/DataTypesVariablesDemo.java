package com.amdocs;

public class DataTypesVariablesDemo {
	public static void main(String[] args) {
		int wholeNumber;		// Declaring a variable
		wholeNumber = 10;		// Initialize a variable
		
		float decimalNumber1 = 12.36f;
		double decimalNumber2 = 199.7353;
		char singleAlphabet = 'a';
		boolean value = true;
		long longIntValue = 2352;
		short shortIntValue = 2324;
		
		System.out.println("The value in Integer is " + wholeNumber);		// Prints in a new line
		System.out.println("The value in Float is " + decimalNumber1);		// Prints in the same line 
		System.out.println("The value in Double is " + decimalNumber2);
		System.out.println("The value in Char is " + singleAlphabet + "\nThe value in Boolean is " + value);	// Escape sequences \n
		System.out.println("\"Hello\" from \"Amdocs\"");
		System.out.println("The value in Long is " + longIntValue + "\nThe value in Short is " + shortIntValue);
	}
}
