package com.amdocs;

import java.util.Iterator;

public class BranchingDemo {
	public static void main(String[] args) {
		breakLoop();
		System.out.println();
		
		breakInfiniteLoop();
		System.out.println();
		
		continueLoop();
		System.out.println();
	}
	
	public static void breakLoop() {
		for (int i = 1; i <= 10; i++) {
			if (i==5) {
				break;			// Terminate your loop
			} else {
				System.out.println(i + ". Hello Java Developers.");
			}
		}
		System.out.println("Outside the loop.");
	} 
	
	public static void breakInfiniteLoop() {
		for (int i = 1; ; i++) {
			if (i==200) {
				break;			// Terminate your loop
			} else {
				System.out.println(i + ". Hello Java Developers.");
			}
		}
		System.out.println("Outside the loop.");
	}
	
	public static void continueLoop() {
		for (int i = 1; i <= 10; i++) {
			if (i==5) {
				continue;			// Terminate your loop
			} else {
				System.out.println(i + ". Hello Java Developers.");
			}
		}
		System.out.println("Outside the loop.");
	} 
}
