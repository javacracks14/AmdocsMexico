package com.amdocs;

public class FirstJavaProgram { 					// Key word to create a class
	public static void main(String[] args) {		// Starting main function
		System.out.print("Hello World!");			
	}
}
