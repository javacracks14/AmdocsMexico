package com.amdocs.caseStudy;

public class Interview {
	private int candidateId;
	private int interviewerId;
	private String date;
	private String time;
	
	public Interview(int candidateId, int interviewerId, String date, String time) {
		this.candidateId = candidateId;
		this.interviewerId = interviewerId;
		this.date = date;
		this.time = time;
	}
	
	public int getCandidateId() {
		return candidateId;
	}
	
	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}
	
	public int getInterviewerId() {
		return interviewerId;
	}
	
	public void setInterviewerId(int interviewerId) {
		this.interviewerId = interviewerId;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		return "Candidate ID: " + this.candidateId + "\nInterviewer ID: " + this.interviewerId + "\nDate: " + this.date + "\nTime: " + this.time + "\n";
	}
	
	public String toCSV() {
		return this.candidateId + "," + this.interviewerId + "," + this.date + "," + this.time;
	}
}
