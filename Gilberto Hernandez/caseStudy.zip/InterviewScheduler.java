package com.amdocs.caseStudy;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.stream.Collectors;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class InterviewScheduler {
	static int candidatecount = 0;
	static int interviewercount = 0;
	
	public static void main(String[] args) {
		ArrayList<Candidate> candidatesData = new ArrayList<>();
		ArrayList<Interviewer> interviewersData = new ArrayList<>();
		ArrayList<Interview> interviewsData = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		
		loadFromFile(candidatesData, interviewersData, interviewsData);
		
		System.out.println("Hello, welcome to the Interview Scheduling System.");
		
		while(true) {
			System.out.println("Please choose one of the following options to perform:\n1.- Add candidate\n2.- Add interviewer\n3.- Schedule interview\n4.- View candidates\n5.- View interviewers\n6.- View scheduled interviews\n7.- Exit (Save data and quit)\n");
			int opt = sc.nextInt();
			sc.nextLine();
			
			switch(opt) {
				case 1:
					addCandidate(candidatesData, sc);
					break;
				case 2:
					addInterviewer(interviewersData, sc);
					break;
				case 3:
					scheduleInterview(interviewsData, candidatesData, interviewersData, sc);
					break;
				case 4:
					viewCandidates(candidatesData);
					break;
				case 5:
					viewInterviewers(interviewersData);
					break;
				case 6:
					viewInterviews(interviewsData);
					break;
				case 7:
					saveToFile(candidatesData, interviewersData, interviewsData);
					System.exit(0);
				default:
					System.out.println("Invalid option. Provide an option within the menu.");
					break;
			}
		}

	}
	
	public static void addCandidate(ArrayList<Candidate> data, Scanner sc) {
		int id = giveMeId(++candidatecount);
		System.out.println("Enter the candidate's name:");
		String name = sc.nextLine();
		System.out.println("Enter the candidate's email:");
		String email = sc.nextLine();
		System.out.println("Enter the applied position:");
		String position = sc.nextLine();
		
		Candidate can = new Candidate(id, name, email, position);
		
		data.add(can);
		
		System.out.println("The candidate has been successfully registered.\n");
	}
	
	public static void addInterviewer(ArrayList<Interviewer> data, Scanner sc) {
		int id = giveMeId(++interviewercount);
		System.out.println("Enter the interviewer's name:");
		String name = sc.nextLine();
		System.out.println("Enter the interviewer's department:");
		String department = sc.nextLine();
		System.out.println("Enter the interviewer's email:");
		String email = sc.nextLine();
		
		Interviewer iwr = new Interviewer(id, name, department, email);
		
		data.add(iwr);
		
		System.out.println("The interviewer has been successfully registered.\n");
	}
	
	public static void scheduleInterview(ArrayList<Interview> data, ArrayList<Candidate> canData, ArrayList<Interviewer> intData, Scanner sc) {
		int canid, intid;
		
		if (canData.isEmpty()) {
			System.out.println("There are no candidates registered, so no interviews can be scheduled.\n");
			return;
		}
		else if (intData.isEmpty()) {
			System.out.println("There are no interviewers registered, so no interviews can be scheduled.\n");
			return;
		}
		
		while(true) {
			System.out.println("Enter the candidate's ID:");
			canid = sc.nextInt();
			boolean checker = checkExistance(canid, canData);
			if(checker) {
				break;
			}
		}
		
		while(true) {
			System.out.println("Enter the interviewer's ID:");
			intid = sc.nextInt();
			boolean checker = checkExistance(intid, intData);
			if(checker) {
				break;
			}
		}
		
		sc.nextLine();
		
		System.out.println("Enter the interview's date(mm/dd/yyyy):");
		String date = sc.nextLine();
		System.out.println("Enter the interview's time(hh:mm):");
		String time = sc.nextLine();
		
		Interview iwr = new Interview(canid, intid, date, time);
		data.add(iwr);
		
		System.out.println("The interview has been successfully scheduled.\n");
	}
	
	public static <T extends Identifiable> boolean checkExistance(int id, ArrayList<T> data) {
		List<T> result = data.stream().filter(i -> i.getId() == id).collect(Collectors.toList());
		if(result.isEmpty()) {
			System.out.println("The provided ID doesn't match any candidate or interviewer registered in the system. Please enter a valid candidate ID.");
			return false;
		}
		return true;
	}
	
	public static void viewCandidates(ArrayList<Candidate> data) {
		if (data.isEmpty()) {
			System.out.println("There are no candidates registered yet.\n");
			return;
		}
		
		System.out.println("List of candidates:\n");
		
		for (Candidate c : data) {
			System.out.println(c);
		}
	}
	
	public static void viewInterviewers(ArrayList<Interviewer> data) {
		if (data.isEmpty()) {
			System.out.println("There are no interviewers registered yet.\n");
			return;
		}
		
		System.out.println("List of interviewers:\n");
		
		for (Interviewer c : data) {
			System.out.println(c);
		}
	}
	
	public static void viewInterviews(ArrayList<Interview> data) {
		if (data.isEmpty()) {
			System.out.println("There are no interviews registered yet.\n");
			return;
		}
		
		System.out.println("List of scheduled interviews:\n");
		
		for (Interview c : data) {
			System.out.println(c);
		}
	}
	
	public static void saveToFile(ArrayList<Candidate> canData, ArrayList<Interviewer> intData, ArrayList<Interview> intwData) {
		try (FileWriter fw = new FileWriter("data.txt")){
			fw.write(candidatecount + "\n");
			fw.write(interviewercount + "\n");
			fw.write("Candidates:\n");
			for (int i = 0; i < canData.size(); i++) {
				canData.get(i).toCSV();
				fw.write(canData.get(i).toCSV() + "\n");
			}
			
			fw.write("\nInterviewers:\n");
			for (int i = 0; i < intData.size(); i++) {
				intData.get(i).toCSV();
				fw.write(intData.get(i).toCSV() + "\n");
			}
			
			fw.write("\nInterviews:\n");
			for (int i = 0; i < intwData.size(); i++) {
				intwData.get(i).toCSV();
				fw.write(intwData.get(i).toCSV() + "\n");
			}
		}
		catch (IOException e) {
			
		}
		
		System.out.println("The information has been saved. Exiting the system.");
	}
	
	public static void loadFromFile(ArrayList<Candidate> canData, ArrayList<Interviewer> intData, ArrayList<Interview> intwData) {
		File file = new File("data.txt");
		if(!file.exists()) {
			try {
				file.createNewFile();
				FileWriter fw = new FileWriter("data.txt");
				fw.write(candidatecount + "\n");
				fw.write(interviewercount + "\n");
				fw.close();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {
			String line;
			String current = "";
			candidatecount = Integer.parseInt(br.readLine());
			interviewercount = Integer.parseInt(br.readLine());
			while ((line = br.readLine()) != null) {
				line = line.trim();
				
				if(line.isEmpty()) {
					continue;
				}
				
				if(line.endsWith(":")) {
					current = line.replace(":", "");
					continue;
				}
				
				String[] fields = line.split(",");

				switch (current) {
					case "Candidates":
						canData.add(new Candidate(Integer.parseInt(fields[0]), fields[1], fields[2], fields[3]));
						break;
					case "Interviewers":
						intData.add(new Interviewer(Integer.parseInt(fields[0]), fields[1], fields[2], fields[3]));
						break;
					case "Interviews":
						intwData.add(new Interview(Integer.parseInt(fields[0]), Integer.parseInt(fields[1]), fields[2], fields[3]));
						break;
				}
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static int giveMeId(int counter) {
		int ids = counter + 1000;
		
		if(ids>=10000) {
			System.out.println("The system has reached the maximum capacity of candidates.");
			System.exit(-1);
		}
		
		return ids;
	}
}
