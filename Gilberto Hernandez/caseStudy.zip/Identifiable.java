package com.amdocs.caseStudy;

public interface Identifiable {
	int getId();
	public String toCSV();
}
