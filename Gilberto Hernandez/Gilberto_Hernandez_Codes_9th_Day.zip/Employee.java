package com.amdocs.ninthDay;

public class Employee implements Comparable<Employee> {
	private int empid;
	private String name;
	private double salary;
	
	public Employee(int empid, String name, double salary) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}
		
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {		// Built in class
		return "EMPID: " + empid + "\tNAME: " + name + "\tSALARY: " + salary ;
	}
	
	@Override
	public int compareTo(Employee emp) {
		Employee firstEmp = emp;
		if(empid<firstEmp.empid) {
			return -1;
		}
		if(empid>firstEmp.empid) {
			return 1;
		}
		else {
			return 0;
		}
	}
}
