package com.amdocs.ninthDay;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class EmployeeArrayList {
	public static void main(String[] args) {
		List<Employee> employeeData = new ArrayList<>();
		
		Employee e1 = new Employee(101,"Jason", 25000.0);
		Employee e2 = new Employee(103,"Tracy", 20000.0);
		Employee e3 = new Employee(104,"Victor", 28000.0);
		Employee e4 = new Employee(102,"Mike", 32000.0);
		Employee e5 = new Employee(105,"Donal", 35000.0);
		
		employeeData.add(e1);
		employeeData.add(e2);
		employeeData.add(e3);
		employeeData.add(e4);
		employeeData.add(e5);
		
		Collections.sort(employeeData);
		
		for (Employee e: employeeData) {
			System.out.println(e);
		}
		
		System.out.println("\nOrder by Employee ID:");
		
		Collections.sort(employeeData, new EmployeeIDCompare());
		
		for (Employee e: employeeData) {
			System.out.println(e);
		}
		
		System.out.println("\nOrder by Employee Name:");
		
		Collections.sort(employeeData, new NameCompare());
		
		for (Employee e: employeeData) {
			System.out.println(e);
		}
		
		System.out.println("\nOrder by Employee Salary:");
		
		Collections.sort(employeeData, new SalaryCompare());
		
		for (Employee e: employeeData) {
			System.out.println(e);
		}
	}
}
